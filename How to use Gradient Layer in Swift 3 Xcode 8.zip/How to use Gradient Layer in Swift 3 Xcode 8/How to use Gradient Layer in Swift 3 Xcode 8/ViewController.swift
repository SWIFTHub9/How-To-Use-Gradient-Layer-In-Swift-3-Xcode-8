//
//  ViewController.swift
//  How to use Gradient Layer in Swift 3 Xcode 8
//
//  Created by Abhishek Verma on 28/07/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var gradient : CAGradientLayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        gradient = CAGradientLayer()
        gradient.frame = self.view.bounds
        gradient.colors = [UIColor.purple.cgColor, UIColor.blue.cgColor]
        self.view.layer.addSublayer(gradient)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle
        {
        return .lightContent
    }


}

